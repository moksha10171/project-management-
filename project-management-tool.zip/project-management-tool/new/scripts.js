document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('create-project').addEventListener('click', function() {
        alert('Create New Project functionality to be implemented.');
    });

    document.querySelectorAll('.view-project').forEach(button => {
        button.addEventListener('click', function() {
            alert('View Project functionality to be implemented.');
        });
    });

    document.getElementById('add-task').addEventListener('click', function() {
        alert('Add New Task functionality to be implemented.');
    });

    document.querySelectorAll('.comment-task').forEach(button => {
        button.addEventListener('click', function() {
            alert('Comment on Task functionality to be implemented.');
        });
    });

    document.querySelectorAll('.mark-complete').forEach(button => {
        button.addEventListener('click', function() {
            this.textContent = 'Completed';
            this.style.backgroundColor = '#28a745';
            this.style.cursor = 'default';
            this.disabled = true;
        });
    });

    document.querySelectorAll('.view-profile').forEach(button => {
        button.addEventListener('click', function() {
            alert('View Profile functionality to be implemented.');
        });
    });
});
