// frontend/src/index.js

import React from 'react';
import ReactDOM from 'react-dom';

const App = () => <h1>Hello, World!</h1>;

ReactDOM.render(
    <App />,
    document.getElementById('app')
);
