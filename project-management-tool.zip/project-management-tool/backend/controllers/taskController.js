// controllers/taskController.js
const Task = require('../models/Task');

exports.createTask = async (req, res) => {
    try {
        const { title, description, assignedTo, project, status } = req.body;
        const newTask = new Task({ title, description, assignedTo, project, status });
        await newTask.save();
        res.status(201).json(newTask);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Add more task-related operations here...
