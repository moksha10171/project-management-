// controllers/projectController.js
const Project = require('../models/Project');

exports.createProject = async (req, res) => {
    try {
        const { name, description, users } = req.body;
        const newProject = new Project({ name, description, users });
        await newProject.save();
        res.status(201).json(newProject);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Add more project-related operations here...
