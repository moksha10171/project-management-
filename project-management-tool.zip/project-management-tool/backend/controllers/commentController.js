// controllers/commentController.js
const Comment = require('../models/Comment');

exports.createComment = async (req, res) => {
    try {
        const { content, author, task } = req.body;
        const newComment = new Comment({ content, author, task });
        await newComment.save();
        res.status(201).json(newComment);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Add more comment-related operations here...
